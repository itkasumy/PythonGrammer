__all__ = ['test1', 'test2']

print('张三被调用了')

