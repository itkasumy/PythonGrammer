def haha():
    print('李四:哈哈')
