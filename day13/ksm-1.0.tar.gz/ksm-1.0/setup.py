from distutils.core import setup

setup(
    name="ksm",
    version="1.0",
    description="ksm's modules",
    author="ksm",
    py_modules=["zhangsan.test1", "zhangsan.test2", "lisi.test1"]
)
