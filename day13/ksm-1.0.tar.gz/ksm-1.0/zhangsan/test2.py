def haha():
    print('张三:哈哈--t2')
